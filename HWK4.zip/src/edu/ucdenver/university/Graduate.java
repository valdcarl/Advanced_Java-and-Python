package edu.ucdenver.university;

import java.time.LocalDate;


// MODIFIED TO PREVENT IT TO INSTANTIATE OBJECTS AND IN CONSEQUENCE REMOVE ITS IMPLEMENTATION OF GETSTANDING()
public abstract class Graduate extends Student {
    // making Graduate an abstract class

    private Graduate(String name, LocalDate dob, String studentId) { super(name, dob, studentId);  }
    // making the constructor private, prevents the Graduate class from instantiating this object
    // added String studentId as 3rd argument
    // as consequence removing the implementation of getStanding()

}

// Modify the Graduate student class to prevent it to instantiate objects
// and in consequence remove its implementation of getStanding()