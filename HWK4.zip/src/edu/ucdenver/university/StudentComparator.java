package edu.ucdenver.university;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Comparator;

public class StudentComparator implements Comparator<Student> {


    @Override
    public int compare(Student stu1, Student stu2) {
        // sort students by ordinal value first, to the other student if equal
        // in standing precedence set, sort student by name
        if(ordinality(stu1) < ordinality(stu2)){
            return -1;
        } else if(ordinality(stu1) > ordinality(stu2)){
            return 1;
        } else {
            // the ordinality is ==, so compare by name and return the sort
            return stu1.getName().compareTo(stu2.getName());
        }
    }


    public int ordinality(Student theStudent){
        // for each standing we are setting an ordinal value as suggested by Javier in homework prompt
        if(theStudent.getStanding().equals("Undergraduate")){
            // undergraduate set with highest precedence
            return 0;
        }
        if(theStudent.getStanding().equals("Master")){
            // master 2nd highest precedence in standing
            return 1;
        }
        if(theStudent.getStanding().equals("PhD")){
            // phd least precedence in standing
            return 2;
        }
        if(theStudent.getStanding().equals("Graduate")){
            // graduate basically removed, however, autograder tool may require according to class discord
            return 3;
        }
        return -1;      // to let us know that no standing has been passed a.k.a. an error
    }
}
