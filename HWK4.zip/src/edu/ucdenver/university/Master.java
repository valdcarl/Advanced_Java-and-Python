package edu.ucdenver.university;

import java.time.LocalDate;

public class Master extends Student {

    public Master(String name, LocalDate dob, String studentId) {
        super(name, dob, studentId);
    }
    // added String studentId as 3rd argument

    @Override
    public String getStanding(){ return "Master"; }
}
