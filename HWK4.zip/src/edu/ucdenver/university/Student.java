package edu.ucdenver.university;

import java.io.Serializable;
import java.time.LocalDate;

// This class student shouldn't be a complete class, should not have a constructor
// Should be an abstract class no?

public abstract class Student implements Serializable {
    private String name;
    private LocalDate dob;
    private String email;
    private String studentId;   // added a String attribute for students that represents the student's id

    public Student(String name, LocalDate dob, String studentId) {
        this.name = name;
        this.dob = dob;
        this.email = name.toLowerCase().replace(" ", ".") + "@ucdenver.edu";
        this.studentId = studentId;     // added as 3rd argument
    }

    @Override
    public String toString() {
        return String.format("%-20s - %s - %-50s - Standing: %s", this.getName(), this.getDob(), this.getEmail(),
                this.getStanding());
    }

    public abstract String getStanding();

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public LocalDate getDob() { return dob; }

    public void setDob(LocalDate dob) { this.dob = dob; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getId() { return studentId; }  // add a getId() getter to return the student's id

    public void setStudentId(String studentId) { this.studentId = studentId; }
}
