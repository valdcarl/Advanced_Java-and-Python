package edu.ucdenver.university;

import java.time.LocalDate;
import java.util.*;

public class University {
    private ArrayList<Student> students;
    private ArrayList<Course> courses;

    public University() {
        this.students = new ArrayList<>(100);   // initial capacity 100 students.
        this.courses = new ArrayList<>(100);    // initial capacity 100 courses.
    }


    @Override
    public String toString() {
        return String.format("University with %d students and %d courses",
                this.getStudents().size(), this.getCourses().size());
    }

    public Student getStudent(String name) throws IllegalArgumentException {
        for (Student s : students) {
            if (s.getName().equalsIgnoreCase(name)) {
                return s;
            }
        }
        throw new IllegalArgumentException("Student not in the University.");
    }

    public Course getCourse(String subject, int number) throws IllegalArgumentException {
        for (Course c : courses) {
            if (c.getSubject().equalsIgnoreCase(subject) && c.getNumber() == number) {
                return c;
            }
        }
        throw new IllegalArgumentException("Course not in Subjects.");
    }

    // Added String studentId as 3rd argument when adding a student of each type
    public void addUndergrad(String name, LocalDate dob, String studentId) {
        students.add(new Undergraduate(name, dob, studentId));
    }

    public void addMaster(String name, LocalDate dob, String studentId) {
        students.add(new Master(name, dob, studentId));
    }

    public void addPhD(String name, LocalDate dob, String studentID, String topic) {
        students.add(new PhD(name, dob, studentID, topic));
    }

    // addCourse method, to add course if not already within' University
    public void addCourse(String subject, int number, String title) throws IllegalArgumentException {
        try {
            this.getCourse(subject, number);
        } catch (IllegalArgumentException ie) {
            this.courses.add(new Course(subject, number, title));
            return; // can do this even if return type is void, to return to caller
        }
        // only gets here if we do not add the new Course
        throw new IllegalArgumentException("The course is already in the Subjects.");
    }


    // getters for list of students and courses
    public ArrayList<Student> getStudents() {
        return students;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }


    // Additions to Homework 4 Below --- COMPLETE

    // Add a method called sortStudents() that takes no argument that will sort the student list --- COMPLETE but autograder issue
    public void sortStudents() {
        students.sort(new StudentComparator());
    }
    // Add a method called countStudentsPerStanding()    --- COMPLETE
        // method takes no args, and returns key-value data structure, where the key is
        // the standing and the value and the integer representing how many students are in each standing (HashMap or Map preferable)
        // method will only include standings that have at least one student in the university
    public HashMap<String, Integer> countStudentsPerStanding() {
        // create a hashmap structure since we want to return a key-value pair to be returns for each standing
        HashMap<String, Integer> standingsMap = new HashMap<>();
        // iterate through the students that exist in our university
        for (Student student : students) {
            // using a string to hold the current students standing
            String theStanding = student.getStanding();

            // in the map, use the .get method for a standing, if its not empty, increment the counter of the standing by 1
            if(standingsMap.get(theStanding) != null){
                standingsMap.replace(theStanding, standingsMap.get(theStanding) + 1);
            } else {
                // otherwise we need to add a new standing to the map using .put method for hashmap
                // since it is a new standing the counter will be set to 1 and no longer null
                standingsMap.put(theStanding, 1);
            }
        }
        // upon creating the HashMap, must iterate through and get the key-value pairs format printed
        for (String sta : standingsMap.keySet()){
            System.out.printf("%s : %d%n", sta, standingsMap.get(sta));
        }
        return standingsMap;
    }// end countStudentPerStanding
    // Add a method called removeStudentById()      --- COMPLETE
        // Method takes a String representing the studentID
        // remove all the students with the passed id
        // if no student matches the id, then IAE w/ the msg
        // "No student found with id:##" where ## is the id received
    /*
        TESTING-NOTES: It is removing the studentId I pass, but the exception is NOT being thrown
                       when I pass a student id that does not exist, keep testing
     */
    public void removeStudentById(String studentId) throws IllegalArgumentException {
        try {
            students.removeIf(s -> s.getId().equals(studentId));
        } catch (IllegalArgumentException iae) {
            throw new IllegalArgumentException("No student found with id:" + studentId);
        }
    }
    // Add a method called randomizeStudentList() --- COMPLETE
        // using collections, randomize the positions of the students in the university student list
        // method will not return the new randomized collection but instead change the actual positions
        // in the university object attribute
    public void randomizeStudentList(){
        Collections.shuffle(students);
    }
}// end University