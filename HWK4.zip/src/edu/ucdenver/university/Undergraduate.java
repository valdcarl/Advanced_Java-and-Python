package edu.ucdenver.university;

import java.time.LocalDate;

public final class Undergraduate extends Student {

    public Undergraduate(String name, LocalDate dob, String studentId) { super(name, dob, studentId); }
    // added String studentId as 3rd argument

    @Override
    public String getStanding(){ return "Undergraduate"; }
}



// Junior example to show final class or final method