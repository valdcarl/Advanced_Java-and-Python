# Name: Carlos A. Valdez
# Course: CSCI 3920 : Advanced Java and Python
# Instructor: Professor Pastorino
# Due: November 26th, 2021
# Description: Homework #7, Implementation of the University program in Python

from course import Course
from student import Student, UnderGrad, Graduate
from university import University

if __name__ == '__main__':

    # university
    my_university = University('UCD')
    print(my_university)
    # university has no students or course

    print()

    # course
    a_course = Course('CSCI', 3920, 'Advanced Programming w/Java & Python')
    print(a_course)
    # course prints correctly

    print()

    # students, and their respective type of student
    # stu0 = Graduate('Jean-luc Picard', 'jeanluc@ucdenver.edu', 'phd')
    # print(stu0)
    # stu1 = Graduate('Wiliam Riker', 'will@ucdenver.edu', 'master')
    # print(stu1)
    # stu2 = UnderGrad('Wesley Crusher', 'wesley@ucdenver.edu', 4)
    # print(stu2)
    # students print correctly

    print()

    # add courses
    my_university.add_course('CSCI', 3543, 'Operating Systems Concepts')
    my_university.add_course('CSCI', 3920, 'Advanced Programming w/Java & Python')
    my_university.add_course('MATH', 1, 'Some Math Course')
    my_university.add_course('MATH', 2000, 'Another Math class')
    print(my_university)
    # correctly adds three courses to the university

    # add students
    my_university.add_graduate('Jean-luc Picard', 'jeanluc@ucdenver.edu', 'phd')
    my_university.add_graduate('William Riker', 'will@ucdenver.edu', 'master')
    my_university.add_undergrad('Wesley Crusher', 'wesley@ucdenver.edu', 4)
    my_university.add_graduate('William Teve', 'will2@ucdenver.edu', 'phd')
    print(my_university)
    # correctly adds four students of either kind to the university

    # testing add student with false gpa
    # my_university.add_undergrad('Wes Cru', 'wes@ucdenver.edu', 5)
    # correctly throws ValueError

    # remove a student
    my_university.remove_student('Wesley Crusher')
    print(my_university)
    # correctly removes a student from the University

    # get the students in the University based on different search criteria
    stu_list = my_university.get_students(email='will')
    # correctly gets the students in the University with 'will' in their email

    # # get the courses in the University based on different search criteria
    course_list = my_university.get_courses(subject='MATH', number=3920)
    # correctly gets the courses in the University with search criteria

    # enroll a student
    my_university.enroll_student('000001', 'CSCI', 3920)
    my_university.enroll_student('000001', 'CSCI', 3543)
    my_university.enroll_student('000002', 'CSCI', 3920)
    my_university.enroll_student('000004', 'MATH', 1)
    my_university.enroll_student('000003', 'MATH', 1)  # correctly, doesn't enroll the student to the course
    my_university.enrollment_report()
    # correctly returns the report dictionary found in enrollment_report
