# Student is an abstract class that represents general students
# properties are read-only
# _ to demonstrate private attributes

from course import Course
from abc import ABC, abstractmethod


class Student(ABC):      # abstract class
    __id_num = '000000'  # should not be accessible from outside the class

    def __init__(self, name: str, email: str):
        """Initialize a Student object"""
        self._name = name

        '''increment by 1'''
        Student.__id_num = str(int(Student.__id_num) + 1).rjust(6, '0')
        self._id = Student.__id_num

        # Need to validate the email is lowercase and has correct extension
        if email.islower() and email.endswith('@ucdenver.edu'):
            self._email = email
        else:
            raise AttributeError('email does not have correct extension or is not lowercase')

        self._enrolled_to = []      # need a list per student to show enrolled courses

    @staticmethod
    def reset_id_numbering():
        """Resets the id numbering"""
        Student.__id_num = '000000'

    @abstractmethod
    def get_standing(self):
        """Base-class Student should have no standing
           and should be abstractmethod for UnderGrad and Graduate"""
        pass

    def enroll_to(self, the_course: Course):
        """Students can be enrolled to one or more classes, or not enrolled at all
           enroll_to receives a course object and adds it to the enrolled_to list"""
        # could do exception if course already exists for the student, but not required in assignment
        self._enrolled_to.append(the_course)

    @property
    def name(self):
        return self._name

    @property
    def id(self):
        return self._id

    @property
    def email(self):
        return self._email

    @property
    def enrolled_to(self):
        return self._enrolled_to

    def __str__(self):
        return "{:20} - {:^10} - {:50} - Standing: {}".format(self._name, self._id, self._email, self.get_standing())
# end Student class


class UnderGrad(Student):
    def __init__(self, name: str, email: str, gpa: float):
        """Initialize a subclass Undergrad from base class Student, has added attribute gpa"""
        super().__init__(name, email)   # undergrad is initialized with same properties as Student
        if not 0.0 <= gpa <= 4.0:
            raise ValueError('gpa cannot fall below 0 or above 4')
        self._gpa = gpa

    def get_standing(self):
        """Get the standing of an Undergraduate student"""
        return 'Undergraduate'

    @property
    def gpa(self):
        """Get the gpa"""
        return self._gpa

    @gpa.setter
    def gpa(self, the_gpa):
        """GPA must fall between float type 0.0 - 4.0, inclusive"""
        if not 0.0 <= the_gpa <= 4.0:
            raise ValueError('gpa cannot fall below 0 or above 4')
        self._gpa = the_gpa

    def __str__(self):
        return super(UnderGrad, self).__str__()
# end UnderGrad class


class Graduate(Student):
    def __init__(self, name: str, email: str, current_level: str):
        """Initialize a subclass Graduate from base class Student, has added attribute current_level, but no gpa"""
        super().__init__(name, email)
        self._current_level = current_level

    def get_standing(self):
        """Get the standing of the Graduate based on current level passed"""
        if self._current_level == 'master':
            return "Master"
        if self._current_level == 'phd':
            return "PhD"

    @property
    def current_level(self):
        return self._current_level

    @current_level.setter
    def current_level(self, the_current_level):
        if the_current_level == 'master' or the_current_level == 'phd':
            self._current_level = the_current_level
        else:
            raise ValueError('level is neither master nor phd')

    def __str__(self):
        return super(Graduate, self).__str__()
# end Graduate class
