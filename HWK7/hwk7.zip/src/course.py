# represents the courses at the University
# all properties are read-only, recall read-only property has only a getter
# _ to demonstrate private attributes


class Course:
    def __init__(self, subject: str, number: int, title: str):
        """Initialize a Course object"""
        self._subject = subject
        self._number = number
        self._title = title

    @property
    def subject(self):
        """Return the subject"""
        return self._subject

    @property
    def number(self):
        """Return the number"""
        return self._number

    @property
    def title(self):
        """Return the title"""
        return self._title

    def __str__(self):
        """Return the str formatted to only output the subject:number"""
        return "{}:{}".format(self._subject, self._number)
# end class Course
