# represents the University which has students and courses
# Student and course lists cannot be retrieved by the clients


from course import Course
from student import Student, UnderGrad, Graduate


class University:
    def __init__(self, name: str):
        """Initialize a University object
           __ since, it cannot be retrieved by the Clients """
        self.__name = name
        self.__all_courses = []   # need to keep track of the courses in the university
        self.__all_students = []  # need to keep track of the students in the university

    def add_undergrad(self, name, email, gpa):
        """add an undergraduate to the University"""
        self.__all_students.append(UnderGrad(name, email, gpa))  # append an undergrad to the students list

    def add_graduate(self, name, email, level):
        """add a graduate to the University"""
        self.__all_students.append(Graduate(name, email, level))  # append a graduate to the students list

    def add_course(self, subject, number, title):
        """add a course to the University, raising ValueError if course
           exists with same subject and number"""
        try:
            # using comprehension to check an elements .subject / .number matches
            # if match, raise the ValueError since it already exists
            for _ in (ele for ele in self.__all_courses if ele.subject == subject and ele.number == number):
                raise ValueError()
        except ValueError as ve:
            print(ve)
        else:
            # otherwise the course doesn't exist, so add it to the courses list
            self.__all_courses.append(Course(subject, number, title))

    def remove_student(self, name):  # list
        """Remove a student from the University, based on name match"""
        for stu in self.__all_students:
            if stu.name == name:
                self.__all_students.remove(stu)  # remove the student from the students list

    def get_students(self, name='', sid='', email=''):
        """Returns a list based on the match of search criteria for students"""
        # for some reason autograder wants it to be sid, so changed to sid
        # hint: use default args and lists/sets to make code simple
        # matching list per specific filter, and compute the intersection
        match_by_name = [ele for ele in self.__all_students if name.lower() in ele.name.lower()]
        match_by_id = [ele for ele in self.__all_students if sid in ele.id]
        match_by_email = [ele for ele in self.__all_students if email in ele.email]

        student_list = list(set(match_by_name) & set(match_by_id) & set(match_by_email))
        return student_list

    def get_courses(self, subject='', number=1, title=''):
        """Returns a list based on the match of search criteria for courses"""
        match_by_subject = [ele for ele in self.__all_courses if subject.lower() in ele.subject.lower()]
        match_by_number = [ele for ele in self.__all_courses if number == ele.number]
        match_by_title = [ele for ele in self.__all_courses if title.lower() in ele.title.lower()]

        course_list = list(set(match_by_subject) & set(match_by_number) & set(match_by_title))
        return course_list

    def enroll_student(self, id, subject, number):
        """Takes the students id and course subject/number and enroll
           the student to the course"""
        # get to use the enroll_to method from a Student object
        the_course = None
        # must check the course subject and number exists in the list of courses
        for a_course in self.__all_courses:
            if a_course.subject == subject and a_course.number == number:
                the_course = a_course
        # must check the student id exists in the list of students
        for a_student in self.__all_students:
            if a_student.id == id:
                # call enroll_to on the student to append to the student's enrolled_to list
                a_student.enroll_to(the_course)

    def enrollment_report(self):
        """Returns a dictionary, where key = string representing the course
           and the value = a list of student enrolled to that course
           e.g., 'CSCI3920'->[stu1, stu2, ...]
           Only courses with enrolled students will appear in the result"""
        enrolled_report = {}    # create the empty dictionary
        for a_student in self.__all_students:   # for a student in all the students
            for a_course in a_student.enrolled_to:  # for a course pertaining to the student
                if a_course in enrolled_report:     # if the course key is in the report
                    # add to list of values(the students) to the corresponding key(the course)
                    enrolled_report[a_course].append(a_student)
                else:
                    enrolled_report[a_course] = [a_student]

        # print the dictionary as described on assignment and e.g. above
        for keys, values in enrolled_report.items():
            print(keys, '->', list(value.name for value in values))

        return enrolled_report

    def __str__(self):
        return "{} University with {} students and {} courses.".format(self.__name, len(self.__all_students),
                                                                       len(self.__all_courses))
