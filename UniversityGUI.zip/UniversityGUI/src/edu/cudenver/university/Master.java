package edu.cudenver.university;


import java.time.LocalDate;

public class Master extends Student {

    public Master(String name, LocalDate dob) {
        super(name, dob);
    }

    @Override
    public String getStanding(){
        return "Master";
    }
}
