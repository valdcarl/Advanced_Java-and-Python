package edu.cudenver.university;

import java.time.LocalDate;

public class PhD extends Student{
    private String dissertationTopic;

    public PhD(String name, LocalDate dob, String dissertationTopic) {
        super(name, dob);
        this.dissertationTopic = dissertationTopic;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(String.format(" - dissertation is about %s", this.getDissertation()));
        return sb.toString();
    }

    @Override
    public String getStanding(){
        return "PhD";
    }

    public String getDissertation(){
        return dissertationTopic;
    }
}
