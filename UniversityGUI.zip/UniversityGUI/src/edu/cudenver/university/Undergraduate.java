package edu.cudenver.university;

import java.time.LocalDate;

public final class Undergraduate extends Student {

    public Undergraduate(String name, LocalDate dob) { super(name, dob); }

    @Override
    public String getStanding(){
        return "Undergraduate";
    }
}



// Junior example to show final class or final method