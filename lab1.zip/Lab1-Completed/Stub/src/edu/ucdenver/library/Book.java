package edu.ucdenver.library;

import java.time.LocalDate;

public class Book {
    /** TODO:        Declare the instance attributes for the book.
     * Follow the software engineering practices discussed in our videos.
     * Review the provided uml to identify data types.
     * - title -------------- Completed
     * - publication date --- Completed
     * - other titles ------- Completed
     * - number of pages. --- Completed
     * - author. ------------ Completed
     */
    private String title;
    private LocalDate publicationDate;
    private String[] otherTitles;
    private int numPages;
    private Author myAuthor;

    /*TODO: The constructor should receive all the data to create the book. (including the author obj)*/
    public Book(String title, LocalDate publicationDate, String[] otherTitles, int numPages, Author myAuthor) {
        this.title = title;
        this.publicationDate = publicationDate;
        this.otherTitles = otherTitles;
        this.numPages = numPages;
        this.myAuthor = myAuthor;
    }

    /*TODO: Add getters and setters for title, publication date, other titles, number of pages*/
    //for title
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    //for publication date
    public LocalDate getPublicationDate() {
        return publicationDate;
    }
    public void setPublicationDate(LocalDate publicationDate) {
        this.publicationDate = publicationDate;
    }

    //for other titles
    public String[] getOtherTitles() {
        return otherTitles;
    }
    public void setOtherTitles(String[] otherTitles) {
        this.otherTitles = otherTitles;
    }

    //for number of pages
    public int getNumPages() {
        return numPages;
    }
    public void setNumPages(int numPages) {
        this.numPages = numPages;
    }

    /*TODO: Add getter/setter for Author*/
    public Author getMyAuthor() {
        return myAuthor;
    }
    public void setMyAuthor (Author myAuthor) {
        this.myAuthor = myAuthor;
    }

    public String toString(){
        /** Todo: Book toString()
         * The string representing the book should look like:
                             Book: [name], with [#pages] pages published on [YYYY-MM-DD] written by [Author].
                             ---a.k.a:[first other title]
                             ---a.k.a:[second other title]
                             ---a.k.a:[so on so forth]
         *See example on Canvas
         **/
        // Hint generate a string and concatenate. You can also use StringBuilder if you want to.
        String returnString = new String("Book: "+title+", with "+numPages+ " published on "+publicationDate+
                " written by "+myAuthor.toString());    // using string concatenation for how the string should be represented
        for (String title:otherTitles){ // need a for look to display othertitles
            returnString = returnString + "\n---a.k.a: "+title;
        }
        return returnString;
    }

    /** Todo: Add getters/setters accordingly to the UML class diagram */
}
