package edu.ucdenver.library;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class Library {
    /** TODO: Declare the instance attributes for the Library.
     * Follow the software engineering practices discussed in our videos.
     * Review the provided uml to identify data types.
     * - library name --- Completed
     * - list of books -- Completed
     * - list of authors- Completed
     *
     * Hint: use ArrayList for lists.
     */
    private String libraryName;         // the library name
    private ArrayList<Book> books;      // of type Book, originally I thought String causing errors
    private ArrayList<Author> authors;  // of type Author, originally I thought String causing errors

    /*TODO: The constructor should receive all the data to create the Library. */
    public Library(String libraryName){
        //Remember to create the list objects here!! (not in the declaration above).
        this.libraryName = libraryName;         //set the name of the library in this default constructor
        this.books = new ArrayList<Book>();     //created the list object for Book
        this.authors = new ArrayList<Author>(); //created the list object for Author
    }

    /*TODO: adds a book. receives all data and a string representing the author name. */
    public void addBook(String title, LocalDate publicationDate, String[] otherTitles, int numPages, String authorName)
    throws IllegalArgumentException{ //Todo: observe this line. It's notifying clients that this method may throw an exception. (no code needed)
        /**
         *   TODO:
         *   Search to retrieve the author object based on the name.
         *      Basically for each author compare the name. remember to use str1.equals(str2) to compare strings.
         *      If found, use keep it and terminate the search.
         *   If the author doesn't exist, throw a IllegalArgumentException notifying that.
         *
         *   Create the book object using the book constructor.
         *   add the book to the list.
         *
         *   NOTE: object (reference) variables should be initialized with null. and you can ask if var == null
          */
        boolean useAuthor = false;  // create a useAuthor variable set to bool false to check if able to add to lists
        for(Author libraryAuthors: authors){ // for loop to check name
            if(libraryAuthors.getAuthorName().equals(authorName)){  // if the author = the authorname
                useAuthor = true;                                   // set the condition to true
                Book aBook = new Book(title, publicationDate, otherTitles, numPages, libraryAuthors); // add a new book
                books.add(aBook);                                   // append to the books ArrayList
                break;
            }
            if(!useAuthor){                                         // if it is not the author, don't change condition
                throw new IllegalArgumentException("Invalid author");   // throw an exception instead
            }
        }
    }

    public void addAuthor(String name) throws IllegalArgumentException{
        /** TODO:
         * Search to check if an author with that name exists.
         *   If the author exists, throw a IllegalArgumentException notifying that.
         *   Look the previous method for inspiration.
         *
         *   Create the author object using it's constructor.
         *   add the author to the list.
         */
        boolean foundAuthor = false;  // create a foundAuthor variable set to bool false to check if able to add to lists
        for(Author libraryAuthors: authors){ // for loop to check if found or not
            if(libraryAuthors.toString().equals(name)) {    // if that author iterated to is = to one of the others already in
                throw new IllegalArgumentException("Author already exists in collection");  // throw an exception
            }
        }   //otherwise its not in the list, so create a new author, and append to list of authors
        Author aAuthor = new Author(name);
        authors.add(aAuthor);
    }

    public String toString(){
        /** Todo: Library toString()
         * The string representing the book should look like:
                                 This is the [name].
                                 == Author List =
                                 [print each author, one per line - add new line after each author]
                                 == Author List =
                                 [print each book, one per line- add new line er each book]
                                 --o--
         * See example on Canvas
         **/
        // Hint generate a string and concatenate. You can also use StringBuilder if you want to. Return that string.
        String returnString = new String("This is the "+getLibraryName()+"\n");
        for (Author author:authors) {
            returnString = returnString + "\n" + author.toString();
        }
        for (Book book:books) {
            returnString = returnString + "\n" + book.toString();
        }
        return returnString;
    }

    //Todo: Getter for the library name. --- Completed
    public String getLibraryName() {
        return libraryName;
    }
}