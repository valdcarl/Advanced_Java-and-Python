package edu.ucdenver.library;

public class Author {
    //ToDo: declare the instance attribute name
    private String authorName;          // -name:String --- Completed

    //ToDo: Implement the constructor that takes the name as argument
    public Author(String authorName) {   // constructor that takes String authorName as arg --- Completed
        this.authorName = authorName;
    }
    //Add the getter only for name.      // getter for getting only the name --- Completed
    public String getAuthorName() { return authorName; }
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    @Override
    public String toString() {
        //Todo: Should return "name (Author)"  where name is the author's name
            // returns a formatted string of the author's name --- Completed
        return String.format("Author: %s", authorName);
    }
}

// Note: In the UML Class Diagram Book will instantiate an Author object using the Author constructor