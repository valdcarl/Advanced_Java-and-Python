# Module will have funcs to do the word counting and process the file


import nltk
import re
from typing import TextIO


def initialize():
    """
    Function will initialize the nltk module, in our case will consist on downloading
    some reference files such as the punctuations and English stop words.

    To download nltk requirements just call the nltk.download
    to download: `stopwords` and `punkt`
    :return: Nothing
    """
    nltk.download('stopwords')
    nltk.download('punkt')


def process_file(filename: str):
    """Given a filename, opens the file and counts how many times each word appears in the file"""
    word_count = {}  # will store word:qty
    file: TextIO
    with open(filename, mode='r', encoding='utf-8') as file:
        while line := file.readline():
            count_line_words(line, word_count)

    return word_count


def count_line_words(line: str, word_count: dict):
    """Takes a line of type string, and the current word_count of type dictionary
    :return: nothing, simply modifies the dictionary receives as reference"""
    all_stopwords = nltk.corpus.stopwords.words('english')      # return list of english top stop words
    # we should remove the word "br" as well. add that to the stop word list
    all_stopwords.append('br')
    tokenize = nltk.tokenize.word_tokenize(line.lower())  # returns a list of words, should be normalized to lower
    words_wo_stopwords = [word for word in tokenize if word not in all_stopwords and re.fullmatch("[A-Z]*[a-z]*", word)]
    # Now we have to clean list  of words, lets process it
    for word in words_wo_stopwords:
        # if word in words_wo_stopwords:
        #     words_wo_stopwords[word] += 1       # update existing key-value pair
        # else:
        #     words_wo_stopwords[word] = 1        # insert new-key value
        # for the key if that word doesn't exist, set it to 0, otherwise add 1 to the already existing word
        word_count[word] = word_count.get(word, 0) + 1


def display_word_dictionary(words: dict, top=15):
    """Display in a formatted table the word and the quantity of occurrences in the file
       for the first n most repeated words.
       Method takes: a dictionary of the form word with values being the quantity"""
    print(f"{'Word':^20} - {'Qty':>15}")    # format to display both the header and the words
    for word, qty in sorted(list(words.items()), key=lambda x: x[1], reverse=True)[:top]:
        print(f"{word:^20} - {qty:>15}")    # format to display both the header and the words

    return words
