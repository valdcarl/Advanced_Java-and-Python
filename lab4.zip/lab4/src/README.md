Members:
    1) Bryan Heckman
    2) Carlos Valdez

Question: What changes would you do to process_file if you want to optionally
          allow the user to provide a previously initialized word count dictionary?

Answer: you would add an input function to take a filename made by the user

        lab4.process_file(input("Input the filename: "))
        # Something along those lines
