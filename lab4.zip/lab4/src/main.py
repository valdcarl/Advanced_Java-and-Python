# This .py file will initialize the environment and make the calls to the funcs in lab4


import lab4


if __name__ == "__main__":
    lab4.initialize()
    word_stuff = lab4.process_file("../data/a1.txt")
    lab4.display_word_dictionary(word_stuff, 20)

