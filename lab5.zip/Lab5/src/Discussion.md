# Experimental Results

Members:
    1) Bryan Heckman
    2) Carlos A. Valdez

## Gather Data
* After running each version of the program, namely _Sequential_, _Threaded_ and _Process_, we collect runtimes and
store those in the following table, for posterior discussion. 

| Program Type | Many Small Files | Few Large Files |
|---           |---:              |---:             |
|Sequential    |0.468 sec         |43.322 sec       |
|Thread-based  |0.531 sec         |43.329 sec       |
|Process-based |10.958 sec        |15.354 sec       |
 
## Discussion
* Discuss with your team these questions:

**A) Did the Multi-threaded program (thread-based) improve the performance of the processing?** 

*If yes, explain why? If no, explain what do you think is the cause of that behavior*

The Multi-threaded program (thread-based) did not improve the performance of the processing.
This is due to the GIL in Python which only allows one thread to be running at a time.
Initially, it is suppose to achieve concurrency, but again, the limitation caused by the GIL
only allows one thread to run at a time.

_

_

_


**B) Did the Multi-Processing program (process-based) improve the performance of the processing?** 

*If yes, explain why? If no, explain what do you think is the cause of that behavior*

Multi-Processing program (process-based) only improves the performance of the processing when
dealing with the larger files (option 2)  This is because, it allows each files to be processed on
separate cores of the CPU.  The performance suffered when dealing with the smaller files (option 1).
This is due to having so many smaller files, only a certain amount of them could be done concurrently
again due to the limitations of the CPU cores.  With so many files, it actually slowed down that time.

_

_

_


**C) Which are the trade-offs of achieving better performance?**

The trade-offs of achieving better performance does depend on which method you prefer.  But,
overall, you would expect that the hardware/software is being utilized more meaning we need
to accommodate more resources whether it be process-based or not.
