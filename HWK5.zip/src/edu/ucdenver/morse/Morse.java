// Morse.java

package edu.ucdenver.morse;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Scanner;

public class Morse implements Serializable { //do we need to implement Serializable?
    // add two private hash maps (instance vars) b/w Strings, to map the encoding representation
        // One will map the characters to the dots and dashes
        // Two will map the dots and dashes to characters
    private final HashMap<Character, String> fromCharToMorse;  // should be final, they are unchanged translations
    private final HashMap<String, Character> fromMorseToChar;  // should be final, they are unchanged translations


    public Morse(){
        // initialize these maps in the constructor
        this.fromCharToMorse = new HashMap<Character, String>();
        this.fromMorseToChar = new HashMap<String, Character>();
        // All Chars to Morse
        this.fromCharToMorse.put('A',".-");
        this.fromCharToMorse.put('B',"-...");
        this.fromCharToMorse.put('C',"-.-.");
        this.fromCharToMorse.put('D',"-..");
        this.fromCharToMorse.put('E',".");
        this.fromCharToMorse.put('F',"..-.");
        this.fromCharToMorse.put('G',"--.");
        this.fromCharToMorse.put('H',"....");
        this.fromCharToMorse.put('I',"..");
        this.fromCharToMorse.put('J',".---");
        this.fromCharToMorse.put('K',"-.-");
        this.fromCharToMorse.put('L',".-..");
        this.fromCharToMorse.put('M',"--");
        this.fromCharToMorse.put('N',"-.");
        this.fromCharToMorse.put('O',"---");
        this.fromCharToMorse.put('P',".--.");
        this.fromCharToMorse.put('Q',"--.-");
        this.fromCharToMorse.put('R',".-.");
        this.fromCharToMorse.put('S',"...");
        this.fromCharToMorse.put('T',"-");
        this.fromCharToMorse.put('U',"..-");
        this.fromCharToMorse.put('V',"...-");
        this.fromCharToMorse.put('W',".--");
        this.fromCharToMorse.put('X',"-..-");
        this.fromCharToMorse.put('Y',"-.--");
        this.fromCharToMorse.put('Z',"--..");
        this.fromCharToMorse.put('1',".----");
        this.fromCharToMorse.put('2',"..---");
        this.fromCharToMorse.put('3',"...--");
        this.fromCharToMorse.put('4',"....-");
        this.fromCharToMorse.put('5',".....");
        this.fromCharToMorse.put('6',"-....");
        this.fromCharToMorse.put('7',"--...");
        this.fromCharToMorse.put('8',"---..");
        this.fromCharToMorse.put('9',"----.");
        this.fromCharToMorse.put('0',"-----");
        // All Morse to Chars
        this.fromMorseToChar.put(".-",'A');
        this.fromMorseToChar.put("-...",'B');
        this.fromMorseToChar.put("-.-.",'C');
        this.fromMorseToChar.put("-..",'D');
        this.fromMorseToChar.put(".",'E');
        this.fromMorseToChar.put("..-.", 'F');
        this.fromMorseToChar.put("--.",'G');
        this.fromMorseToChar.put("....",'H');
        this.fromMorseToChar.put("..",'I');
        this.fromMorseToChar.put(".---",'J');
        this.fromMorseToChar.put("-.-",'K');
        this.fromMorseToChar.put(".-..",'L');
        this.fromMorseToChar.put("--",'M');
        this.fromMorseToChar.put("-.",'N');
        this.fromMorseToChar.put("---",'O');
        this.fromMorseToChar.put(".--.",'P');
        this.fromMorseToChar.put("--.-",'Q');
        this.fromMorseToChar.put(".-.",'R');
        this.fromMorseToChar.put("...",'S');
        this.fromMorseToChar.put("-",'T');
        this.fromMorseToChar.put("..-",'U');
        this.fromMorseToChar.put("...-",'V');
        this.fromMorseToChar.put(".--",'W');
        this.fromMorseToChar.put("-..-",'X');
        this.fromMorseToChar.put("-.--",'Y');
        this.fromMorseToChar.put("--..",'Z');
        this.fromMorseToChar.put(".----",'1');
        this.fromMorseToChar.put("..---",'2');
        this.fromMorseToChar.put("...--",'3');
        this.fromMorseToChar.put("....-",'4');
        this.fromMorseToChar.put(".....",'5');
        this.fromMorseToChar.put("-....",'6');
        this.fromMorseToChar.put("--...",'7');
        this.fromMorseToChar.put("---..",'8');
        this.fromMorseToChar.put("----.",'9');
        this.fromMorseToChar.put("-----",'0');
    }

    /*
    Encoding/Decoding characteristics:
        Use the representation given in the image above.
        After each character add an equal sign (=).
        After each word, add an space.  Do not add space after the last word
        (at the end of the sentence)

    Implement the instance methods to encode/decode as follows:
        Implement the encode(String) method, that given a clean string(normal text)
        will return the Morse Code encoded representation
            Example:
            Input String: "HELLO WORLD"
            Output String: "....=.=.-..=.-..=---= .--=---=.-.=.-..=-..="
     */
    public String encode(String theString) {
        String encodedOutputString = "";    // to be returned/output to the user

        // need to parse the string passed
        for(int i = 0; i < theString.length(); i++) {
            char charInString = theString.charAt(i);        // check each character in the string
            if(charInString == ' '){                        // if it's a space, put a space in the output as well
                encodedOutputString = encodedOutputString + " ";
            }
            else {      // otherwise it's a potential char, check it against the map, and append to the output String
                encodedOutputString = encodedOutputString +
                        fromCharToMorse.get(Character.toUpperCase(charInString)) + ("=");
            }
        }
        return encodedOutputString;
    }

    /*
       Implement the encode(String) method, that given a coded string(morse text)
       will return the Normal Code encoded representation
            Example:
            Input String: "....=.=.-..=.-..=---= .--=---=.-.=.-..=-..="
            Output String: "HELLO WORLD"
     */
    public String decode(String encodedString) {
        // Recall in decode I am checking a string of dots/dashes/='s/spaces,
        // aka an already encoded string, such as ....=.=., etc.
        String decodedString = "";    // to be returned/output to the user

        // need to parse the string passed
        for(int i = 0; i < encodedString.length(); i++) {
            char charInString = encodedString.charAt(i);        // check each character in the string
            if (charInString == ' '){                           // if it's a space, put a space in the output as well
                decodedString = decodedString + " ";
            }
            else {
                String ds2 ="";     // a string to hold, the dots and dashes up until we come across a delimiter, =
                while(encodedString.charAt(i) != '=') {
                    // parse through, add to the string holder, and increment index until we come across the delimiter
                    ds2 = ds2 + encodedString.charAt(i);
                    i ++;
                }
                // the output string will have the appropriate spaces, and each combination of dots and dashes
                // met prior to the delimiter will be translated from the map
                decodedString = decodedString + fromMorseToChar.get(ds2);
            }
        }
        return decodedString;
    }


    public static void main(String[] args){
            // Create object of type Morse
        Morse morse = new Morse();
            // Create a scanner object for users input
        Scanner scanner1 = new Scanner(System.in);
            // Prompt the user to enter a string to convert from normal text to morse code
        System.out.print("Enter a string to encode: ");
            // Store the scanned input into theInput
        String theInput = scanner1.nextLine();
            // Call our encoded method and store it into encoded String
        String encoded = morse.encode(theInput);
            // print the encoded string
        System.out.printf("Encoded message translates to: %s", encoded);
        System.out.println();
        System.out.println();
        System.out.println();

            // Create a scanner object for morse code user input
        Scanner scanner2 = new Scanner(System.in);
            // Prompt the user to enter a string to convert from morse code to normal text
        System.out.print("Enter a string to decode: ");
            // Store the scanned input into the morseInput
        String morseInput = scanner2.nextLine();
            // Call our decoded method and store it into decoded String
        String decoded = morse.decode(morseInput);
            // Print the decoded string
        System.out.printf("Decoded message translates to: %s", decoded);
        System.out.println();
        System.out.println();
        System.out.println();


    } // main
} // end Morse Class
