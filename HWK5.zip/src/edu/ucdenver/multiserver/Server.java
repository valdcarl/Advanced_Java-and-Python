// Server.java, implements Runnable interface

package edu.ucdenver.multiserver;

import edu.ucdenver.morse.Morse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable{    // Server should implement Runnable interface
    // two private final variables, the port and backlog to open the server
    private final int port;
    private final int backlog;
    private ServerSocket serverSocket;
    private final Morse morse;


    // constructor should take the port and backlog to open the server
    public Server(int port, int backlog){
        this.port = port;
        this.backlog = backlog;
        this.morse = new Morse();
    }

    public Server() {
        this(10000, 100);
    }

    //Override the following public methods:
    @Override
    /*
    public void run()
        This will implement your server. Similar to runServer()
        from our lecture examples

        Upon a client connection, the server will listen for requests.
        Once one is received, will be processed (see below) and the
        response will be sent to the server.

        Keep accepting requests until the client disconnect.  No termination
        message will be sent, the client will just disconnect.
     */
    public void run() {

        try {
            // creating a socket on the server to listen on port, open
            this.serverSocket = new ServerSocket(this.port, this.backlog);
            Socket clientConnection = null;
            BufferedReader input = null;
            PrintWriter output = null;

            while (true) {
                try {
                    System.out.println("Waiting for a connection....");
                    clientConnection = serverSocket.accept();
                    System.out.printf("Connection accepted from %s", clientConnection.getInetAddress().getHostName());
                    System.out.println();
                    System.out.println("Getting Data Streams");
                    output = new PrintWriter(clientConnection.getOutputStream(), true);
                    input = new BufferedReader(new InputStreamReader(clientConnection.getInputStream()));

                    Thread.sleep(5000);

                    String clientMessage = input.readLine();    // the client will send the message E|Hello World
                    System.out.println("CLIENT SAID >>>" + clientMessage);  // print that message on server output window
                    String[] arguments = clientMessage.split("\\|");  // splits the string using | as the delimiter
                    try {
                        switch (arguments[0]) { // arguments[0] must be the command
                            case "E":   // encode
                                String response = morse.encode(arguments[1]);    // do encode on the text
                                // haven't figured out a way to send the 0| without altering the decode case as well
                                output.println(response);                        // send to client
                                break;
                            case "D":   // decode
                                //morse.decode(arguments[1]);    // do decode on the text
                                response = morse.decode(arguments[1]);
                                output.println(response);
                                break;
                            default:
                                response = "2|Invalid Message Format";
                                System.out.println(response);
                                break;
                        }
                    } catch (IllegalArgumentException | NullPointerException ie) {
                        ie.printStackTrace();
                    }
                } catch (InterruptedException | NullPointerException ie) {
                    ie.printStackTrace();
                } finally {
                    try {
                        input.close();
                        output.close();
                        clientConnection.close();
                        serverSocket.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("\n ====== Cannot Open the server =======");
            e.printStackTrace();
        }
    } // end run

    public static void main(String[] args){
        Server server = new Server();
        server.run();
    }

} // end Server class
