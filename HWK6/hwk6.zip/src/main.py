import hw6

hw6.split_number(123)

hw6.is_palindrome(15561)
hw6.is_palindrome(123321)

hw6.compute_variance(1, 2, 3, 4, 5, 4, 3, 4, 3)

hw6.compute_variance_req(1)
hw6.compute_variance_req(1, 2, 3, 4, 5, 4, 3, 4, 3)

hw6.compute_change_few_coins(40.15)

hw6.binary_to_decimal("0")
hw6.binary_to_decimal("01")
hw6.binary_to_decimal("1101")

hw6.factorial(2)

hw6.approx_pie(1000)

hw6.approx_e(5)
