# hw6.py
# Name: Carlos A. Valdez
# Class: CSCI 3920: Advanced Programming in Python & Java
# Due: November 12th, 2021 by 5pm
# Description: HW#6, start of Python section covering Chapter 1-4 from textbook
#              discussed week #9 Fall 2021.


# 1 Function: split_number          --- Complete, works on auto-grader
def split_number(int_value):
    """
    Takes an integer value
    :return: returns a string with digit, space, digit, space, ..., digit.
    (no space at the end) for each digit in the number.
    :example: 123 will return "1 2 3"
    """
    string_of_int_value = str(int_value)    # cast int_value to be a string and store in new variable
    split_string = ""                       # to hold split_number string to be output
    for i in string_of_int_value:           # iterate over the string of the integer value
        split_string += i + " "             # append each 'char' and a space to split_string
    final_string_output = split_string.strip()  # strip excessive whitespace
    print(final_string_output)              # output the string to console for testing
    return final_string_output              # return the final string output (for auto-grader)


# 2 Function: is_palindrome          --- Complete, works on auto-grader
def is_palindrome(int_value):
    """
    Takes an integer value
    :return:  returns True if the number is a palindrome, False otherwise
    :example: 15561 will return False, for 1233321 will return True

    as caveat, be sure to use print(hw6.is_palindrome(your_value)) to check return
    """
    # simply compare the original value passed casted to string and compare it
    # to the same value passed casted to string backwards using slicing
    if str(int_value) == str(int_value)[::-1]:
        return True     # if they match return True
    else:
        return False    # otherwise, they are not the same, return False


# 3 Function: compute_variance          --- Complete, works on auto-grader
def compute_variance(*args):
    """
    Takes arbitrary number of arguments and computes the variance
    The Variance is computed sigma^2 = {1} / (m-1) the summation from i = 1 to m
    (xsubi - xbar)^2 where m is the number of elements to compute the variance,
    xsubi is the ith element and xbar is the mean of the values.
    :example: hw6.compute_variance(1,2,3,4,5,4,3,4,3) will return
    1.4444444444444446
    :return: the variance (a decimal value - float/double)
    """
    # need a variable to hold the summation from i to m elements
    summation = 0
    # need a variable to hold the mean of the values / the amount of elements
    mean = 0
    # need a variable to represent the number of elements that exists
    m = len(args)
    # need to compute the variance with equation provided
    variance = 0
    for i in args:
        summation += i   # summation of all the elements passed
    mean = summation / m
    for i in args:
        variance = variance + ((i - mean)**2)   # (ith element - mean)^2

    variance_output = round(variance / (m - 1), 6)  # Rounded to 6 decimal values, as suggested by auto-grader
    print(variance_output)                   # print for testing
    return variance_output                   # { } / (m-1)


# 4 Function: compute_variance_req          --- Complete, works on auto-grader
def compute_variance_req(*args):
    """
    Takes arbitrary number of arguments and computes the variance
    The Variance is computed sigma^2 = {1} / (m-1) the summation from i = 1 to m
    (xsubi - xbar)^2 where m is the number of elements to compute the variance,
    xsubi is the ith element and xbar is the mean of the values.
    :example: hw6.compute_variance(1,2,3,4,5,4,3,4,3) will return
    1.4444444444444446

    ***The same but must have a minimum of 2 args else error printed***

    :return: the variance (a decimal value - float/double)
    """
    # need a variable to hold the summation from i to m elements
    summation = 0
    # need a variable to hold the mean of the values / the amount of elements
    mean = 0
    # need a variable to represent the number of elements that exists
    m = len(args)
    # need to compute the variance with equation provided
    variance = 0
    if len(args) >= 2:
        for i in args:
            summation += i   # summation of all the elements passed
        mean = summation / len(args)
        for i in args:
            variance = variance + ((i - mean)**2)   # (ith element - mean)^2

        variance_output = round(variance / (m - 1), 6)  # Rounded to 6 decimal values, as suggested by auto-grader
        print(variance_output)       # print for testing
        return variance_output       # { } / (m-1)
    else:
        error_message = "Must have at least two arguments to compute the variance."
        print(error_message)        # print for testing
        return error_message


# 5 Function: compute_change_few_coins          --- Complete, works on auto-grader
def compute_change_few_coins(amount):
    """
    Takes a real number representing the change a cashier will give the customer.
    It will compute, the min number of coins to give the customer for the exact amount of change.
    :return: A tuple specifying the quantity of coins of each value to give the customer
             Tuple order will be (Dollar, quarter, dime, nickel, penny)
                                    $1  ,  $0.25 ,$0.10, $0.05 , $0.01
    HINT: Do not use decimals to compute the small coins but change the scale to use integers
    """
    # we pass an amount as param such as $23.73
    # we should convert the amount passed as all change, to appropriately modulus all the change/dollars/etc.
    # 1 dollar is 100 cents, using Hint provided let's multiple amount by 100 and cast as int
    total_cents = int(amount * 100)
    change_list = []    # list to append to as we go through each amount
    # // returns the floor value after division, which we want to properly take all dollars
    dollars = total_cents // 100
    total_cents = total_cents % 100    # what remains is what is to be divided amongst the other coins

    change_list.append(dollars)

    quarters = total_cents // 25
    total_cents = total_cents % 25

    change_list.append(quarters)

    dimes = total_cents // 10
    total_cents = total_cents % 10

    change_list.append(dimes)

    nickels = total_cents // 5
    total_cents = total_cents % 5

    change_list.append(nickels)

    pennies = total_cents // 1
    total_cents = total_cents % 1
    change_list.append(pennies)

    change_tuple = tuple(change_list)   # cast to a tuple so that it is unchanged and meets requirement

    print(change_tuple)         # print for testing
    return change_tuple         # return said tuple


# 6 Function: binary_to_decimal          --- Complete, works on auto-grader
def binary_to_decimal(binary_string):
    """
    Takes a string as arg, containing a sequence of all 0's and 1's
    :return: decimal num equivalent to the received binary string; an int
    :example: for "01" will return 1, for "1101" will return  13
    """
    # Python integer method allows us to change base to interpret a given string
    binary = int(binary_string, 2)
    print(binary)           # print for testing
    return binary


# 7 Function: factorial          --- Complete, works on auto-grader
def factorial(n):
    """
    Implements an iterative factorial, Takes an integer n as argument
    The method needs to be computed interactively ( no recursion )
    :returns: n!
    """
    factorial_value = 1         # base case of factorial
    for i in range(1, n + 1):   # iterate from 1 to value_passed (inclusive)
        factorial_value = factorial_value * i   # perform factorial equation
    # print(factorial_value)    for testing
    return factorial_value


# 8 Function: approx_pie          --- Complete, works on auto-grader
def approx_pie(n):
    """
    Approximates the value of pi.  Takes an integer argument representing
    the number of terms used to compute the approximation

    The approximation is computed as π = 4− 4/3 + 4/5 − 4/7 + 4/9 − 4/11 +...
    where -4/3 is the first term and -4/11 is the fifth term
    :return: the approximated pi
    """
    # the denominator is always incremented by 2 as shown in the sequence
    denominator = 1
    # initializing the variable that will add all the elements of the series
    summation = 0
    for i in range(n+1):    # we must do it up to the value passed (inclusive)
        if i % 2 == 0:      # if the value is even be sure to do addition with the fraction
            summation += 4/denominator
        else:               # if the value is odd be sure to do subtraction with the fraction
            summation -= 4/denominator

        denominator += 2    # always increment the denominator by 2 as stated prior

    print(summation)        # print for testing
    return summation


# 9 Function: approx_e          --- Complete, works on auto-grader
def approx_e(n):
    """
    Approximates the value of the number  e = 2.718281828459045
    Takes an integer representing the number of terms used to compute
    the approximation

    The approximation is computed as e = 1 + 1/1! + 1/2! + 1/3! + 1/4! + 1/5!+...
    :return: The approximated e
    """
    # initializing the variable that will add all the elements of the series to 1
    # 1 b/c first value in the series of equation given
    summation = 1
    # iterate from 1 to value_passed (n + 1 with inclusivity was crashing my test on auto-grader
    # although a lot of documentation had to n + 1 for better approximations)
    for i in range(1, n):
        summation = summation + (1/factorial(i))  # following equation as given and using own factorial() method

    rounded_summation = round(summation, 10)    # auto-grader wants it rounded to 10-decimal places
    print(rounded_summation)                    # print for testing
    return rounded_summation
